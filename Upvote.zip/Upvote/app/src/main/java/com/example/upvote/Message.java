package com.example.upvote;

import java.util.ArrayList;

public class Message
{
    private int score;
    private User user;
    private String title;
    private String body;
    private ArrayList<Message> replies;
    private boolean reply;

    public Message(String messa, String bod, boolean rep)
    {
        score = 0;
        body = bod;
        title = messa;
        reply = rep;
        if(!reply)
            replies = new ArrayList<>();
    }

    public void incrementScore()
    {
        score++;
    }

    public void decrementScore()
    {
        score--;
    }

    public int getScore()
    {
        return score;
    }

    public ArrayList<Message> getReplies()
    {
        return replies;
    }

    public void addReply(Message reply)
    {
        replies.add(reply);
    }

    public void delReply(int index)
    {
        replies.remove(index);
    }

    public boolean isReply()
    {
        return reply;
    }

    public String toString()
    {
        String titl = title;
        String bod = body;
        titl = titl.toUpperCase();
        return title + "\n" + bod;
    }
}
