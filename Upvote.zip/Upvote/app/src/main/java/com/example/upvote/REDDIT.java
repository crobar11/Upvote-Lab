package com.example.upvote;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.view.View;
import android.widget.Toast;


import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;


// need to figure out how to add buttons or something with each newly created post

public class REDDIT extends AppCompatActivity {

    private FirebaseDatabase database;
    private DatabaseReference myRef;

    private ChildEventListener childEventListener;

    private ArrayList<Message> postList;
    private ArrayList<String> posts;

    private ListView listView;

    //private ArrayList<String> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reddit);

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Posts");

        postList = new ArrayList<Message>();
        listView = (ListView) findViewById(R.id.listview);

        postList = new ArrayList<Message>();
        posts = new ArrayList<String>();


    }

    public void makePost(View view)
    {
        //Makes and uploads message to database
        EditText editName = findViewById(R.id.titleEditText);
        String title = editName.getText().toString();
        EditText editNumber = findViewById(R.id.mainEditText);
        String body = editNumber.getText().toString();

        if(title.length() > 0 )
        {
            String key = myRef.push().getKey();
            Message c = new Message(title, body, false);
            myRef.child(key).setValue(c + c.toString());

            Toast.makeText(this, "Successfully Added", Toast.LENGTH_LONG).show();
        }
        editName.setText("");
        editNumber.setText("");
        //////////////////////////////////////////

        // Adds the actual post to the app
        postList.add(new Message(title, body, false));

        posts.clear();

        for(int x = 0; x < postList.size(); x++)
        {
            posts.add(postList.get(x).toString());
        }

        ArrayAdapter arrayAdapter = new  ArrayAdapter(this, android.R.layout.simple_list_item_1, posts);

        listView.setAdapter(arrayAdapter);
        /////////////////////////////////////////

    }

   /*public void deletePost(View view) // find out the flag thing first
    {
        posts.clear();

        if(postList.isEmpty() == false) {
            posts.remove(posts.size() - 1);

            ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, posts);

            listView.setAdapter(arrayAdapter);
        }
        else Toast.makeText(this, "Nothing To Delete", Toast.LENGTH_LONG).show();

    }*/
}
